package entities;

public class Moto extends Veiculo {
    private boolean temCarenagem;

    public Moto(String placa, int ano, String modelo, boolean temCarenagem) {
        super(placa, ano, modelo);
        this.temCarenagem = temCarenagem;
    }

    public boolean isTemCarenagem() {
        return temCarenagem;
    }

    public void setTemCarenagem(boolean temCarenagem) {
        this.temCarenagem = temCarenagem;
    }

    @Override
    public String toString() {
        return "Moto [placa=" + getPlaca() + ", ano=" + getAno() + ", modelo=" + getModelo() + ", carenagem=" + temCarenagem + "]";
    }
}
