package entities;

public class Carro extends Veiculo {
    private int numeroDePortas;

    public Carro(String placa, int ano, String modelo, int numeroDePortas) {
        super(placa, ano, modelo);
        this.numeroDePortas = numeroDePortas;
    }

    public int getNumeroDePortas() {
        return numeroDePortas;
    }

    public void setNumeroDePortas(int numeroDePortas) {
        this.numeroDePortas = numeroDePortas;
    }

    @Override
    public String toString() {
        return "Carro [placa=" + getPlaca() + ", ano=" + getAno() + ", modelo=" + getModelo() + ", portas=" + numeroDePortas + "]";
    }
}
